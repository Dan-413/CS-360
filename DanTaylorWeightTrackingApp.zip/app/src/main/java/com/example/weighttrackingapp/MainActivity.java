package com.example.weighttrackingapp;

import android.content.ContentValues;
import android.database.Cursor;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    WeightData myDb;
    EditText editDate, editWeight, editId;
    GridView gridView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myDb = new WeightData(this);
        editDate = findViewById(R.id.editTextDate);
        editWeight = findViewById(R.id.editTextWeight);
        editId = findViewById(R.id.editTextId);
        gridView = findViewById(R.id.DailyWeightData);

        Button addButton = findViewById(R.id.buttonAdd);
        Button updateButton = findViewById(R.id.buttonUpdate);
        Button deleteButton = findViewById(R.id.buttonDelete);
        Button notificationSettingsButton = findViewById(R.id.buttonNotificationSettings);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addData();
            }
        });

        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateData();
            }
        });

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteData();
            }
        });

        // Set click listener for Notification Settings button
        notificationSettingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open NotificationActivity
                Intent intent = new Intent(MainActivity.this, NotificationActivity.class);
                startActivity(intent);
            }
        });

        // Initialize other UI elements and adapters as needed
        // ...

        populateGridView();

        // Set click listener for grid items
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Handle item click (e.g., pre-fill form for update)
                Cursor data = myDb.getAllData();
                data.moveToPosition(position);

                editId.setText(data.getString(0));
                editDate.setText(data.getString(1));
                editWeight.setText(String.valueOf(data.getDouble(2)));
            }
        });
    }

    private void addData() {
        String date = editDate.getText().toString();
        String weightStr = editWeight.getText().toString();

        if (date.isEmpty() || weightStr.isEmpty()) {
            Toast.makeText(this, "Please enter date and weight", Toast.LENGTH_SHORT).show();
            return;
        }

        double weight = Double.parseDouble(weightStr);

        boolean isInserted = myDb.addData(date, weight);

        if (isInserted) {
            Toast.makeText(this, "Data Inserted", Toast.LENGTH_SHORT).show();
            clearFields();
            populateGridView();
        } else {
            Toast.makeText(this, "Error inserting data", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateData() {
        String id = editId.getText().toString();
        String date = editDate.getText().toString();
        String weightStr = editWeight.getText().toString();

        if (id.isEmpty() || date.isEmpty() || weightStr.isEmpty()) {
            Toast.makeText(this, "Please select an item and enter date and weight", Toast.LENGTH_SHORT).show();
            return;
        }

        double weight = Double.parseDouble(weightStr);

        boolean isUpdated = myDb.updateData(id, date, weight);

        if (isUpdated) {
            Toast.makeText(this, "Data Updated", Toast.LENGTH_SHORT).show();
            clearFields();
            populateGridView();
        } else {
            Toast.makeText(this, "Error updating data", Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteData() {
        String id = editId.getText().toString();

        if (id.isEmpty()) {
            Toast.makeText(this, "Please select an item to delete", Toast.LENGTH_SHORT).show();
            return;
        }

        Integer deletedRows = myDb.deleteData(id);

        if (deletedRows > 0) {
            Toast.makeText(this, "Data Deleted", Toast.LENGTH_SHORT).show();
            clearFields();
            populateGridView();
        } else {
            Toast.makeText(this, "Error deleting data", Toast.LENGTH_SHORT).show();
        }
    }

    private void populateGridView() {
        Cursor data = myDb.getAllData();
        ArrayList<String> listData = new ArrayList<>();
        while (data.moveToNext()) {
            listData.add(data.getString(0) + ": " + data.getString(1) + " - " + data.getDouble(2));
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listData);
        gridView.setAdapter(adapter);
    }

    private void clearFields() {
        editId.setText("");
        editDate.setText("");
        editWeight.setText("");
    }

}

