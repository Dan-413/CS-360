package com.example.weighttrackingapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class NotificationActivity extends AppCompatActivity {

    private Switch notificationSwitch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);

        // Initialize views

        notificationSwitch = findViewById(R.id.switch1);
        ImageView imageView = findViewById(R.id.imageView3);
        Button backButton = findViewById(R.id.buttonBack);



        // Set switch listener
        notificationSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    // Handle notification ON
                    Toast.makeText(NotificationActivity.this, "Notifications ON", Toast.LENGTH_SHORT).show();
                } else {
                    // Handle notification OFF
                    Toast.makeText(NotificationActivity.this, "Notifications OFF", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Set back button listener
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle back button click
                finish(); // Close the activity
            }
        });
    }
}

